class ModelRuang {
  final String name;
  final String image;

  ModelRuang({required this.name, required this.image});
}
