class ModelDatar {
  final String name;
  final String image;

  ModelDatar({required this.name, required this.image});
}
