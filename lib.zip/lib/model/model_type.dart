class ModelType {
  final String name;
  final String image;

  ModelType({required this.name, required this.image});
}
