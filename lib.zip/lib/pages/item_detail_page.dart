import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/item_provider.dart';

class ItemDetailPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final selectedItem = Provider.of<ItemProvider>(context).selectedItem;

    return Scaffold(
      appBar: AppBar(
        title: Text(selectedItem?.name ?? 'Item Detail'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (selectedItem != null) ...[
              Image.asset(
                selectedItem.image,
                width: 200,
                height: 200,
                fit: BoxFit.cover,
              ),
              SizedBox(height: 10),
              Text(
                selectedItem.name,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),

              Container(
                width: 200,
                child: TextField(
                  decoration: InputDecoration(
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Color(0xFF000000), width: 1),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Color(0xFF777777), width: 1),
                    ),
                    contentPadding:
                        EdgeInsets.only(top: 5, left: 15, bottom: -12),
                  ),
                ),
              ),
              Spacer(),
              // Add more details as neededf
            ] else
              Text('No item selected'),
          ],
        ),
      ),
    );
  }
}
